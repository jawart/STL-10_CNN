The content has been removed due to big size of data.
Perform the .ipynb files to fill this folder with data again.
