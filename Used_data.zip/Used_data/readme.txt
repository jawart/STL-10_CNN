The content has been removed due to big size of data.
Perform the files:
Module_0_Data_preprocessing.ipynb
and
Module_2_Data_augmentation.ipynb
to fill this folder with data again.
